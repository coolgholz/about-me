const form = document.getElementById('guest-form');
const entries = document.getElementById('entries');
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const name = document.getElementById('guest-name').value.trim();
  const message = document.getElementById('guest-message').value.trim();
  if (!name || !message) return;
  const item = document.createElement('div');
  item.className = 'entry';
  const author = document.createElement('b');
  author.textContent = name + ': ';
  const words = document.createElement('span');
  words.textContent = message;
  item.append(author, words);
  if (entries.querySelector('.small-note')) entries.innerHTML = '';
  entries.prepend(item);
  form.reset();
});
